"""
Utilities for logic package.
"""
