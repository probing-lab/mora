"""
Various algorithms for solving CNF-SAT problem.
"""
