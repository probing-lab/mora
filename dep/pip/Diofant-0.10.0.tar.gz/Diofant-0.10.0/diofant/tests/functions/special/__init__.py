"""
Tests for special functions.
"""
