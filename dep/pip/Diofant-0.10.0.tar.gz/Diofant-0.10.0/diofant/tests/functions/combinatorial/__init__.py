"""
Tests for combinatorial functions.
"""
