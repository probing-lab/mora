===========
SymPy 0.5.5
===========

20 Oct 2007

* ``sympy.abc`` module for quickly importing predefined symbols.
* Nice pretty printing when a unicode terminal is available.
* ``isympy -c python`` now also supports true division.
* Documentation improved (``sympy`` module, ``bin/isympy`` and it's man page).
* A lot of problems with series expansion fixed.
* Patched pyglet to conform to Debian policy.
