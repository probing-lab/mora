===========
SymPy 0.5.0
===========

12 Aug 2007

* New core (from 10x to 100x speedup compared to 0.4.3).
* Multivariate functions.
* Pattern matching uses the Wild and WildFunction classes.
* Numerics module for fast arbitrary-precision numerical computations.
* Plotting module improved (colormaps, middle mouse button for zooming and more).
* sympy/modules/* was moved to sympy/* and the sympy/modules directory was deleted.
