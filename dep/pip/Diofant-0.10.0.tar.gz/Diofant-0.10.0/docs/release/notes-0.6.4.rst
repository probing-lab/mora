===========
SymPy 0.6.4
===========

4 Apr 2009

* robust and fast (still pure Python) multivariate factorization
* sympy works with pickle protocol 2 (thus works in ipython parallel)
* ./sympy test now uses our testing suite and it tests both regular tests and doctests
* examples directory tidied up
* more trigonometric simplifications
* polynomial roots finding and factoring vastly improved
* mpmath updated
* many bugfixes (more than 200 patches since the last release)
