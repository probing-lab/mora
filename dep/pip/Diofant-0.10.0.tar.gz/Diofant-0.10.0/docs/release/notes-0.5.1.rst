===========
SymPy 0.5.1
===========

12 Aug 2007

* importing sympy (import sympy) was made a lot faster (2.4s against 0.1s)
