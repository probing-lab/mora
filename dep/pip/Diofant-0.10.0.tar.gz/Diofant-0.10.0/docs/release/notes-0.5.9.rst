===========
SymPy 0.5.9
===========

22 Dec 2007

* Differential solvers were polished.
* ``isympy`` now predefines ``f`` as a function.
* Matrix printing improved.
* Printing internals were documented.
