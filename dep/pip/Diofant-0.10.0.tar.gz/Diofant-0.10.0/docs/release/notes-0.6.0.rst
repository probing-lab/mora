===========
SymPy 0.6.0
===========

7 Jul 2008

* all documentation wiki pages moved to https://docs.sympy.org/
* mpmath was integrated in SymPy, numerics module removed
* mpmath can use gmpy optionally, thus calculating 1000000 digits of pi in 7.5s
* Common subexpression elimination implemented
* roots, RootsOf, RootSum implemented
* ``lambdify()`` now accepts Matrices
* Matrices polished and spedup
* source command implemented
* Polys were made the default polynomials in SymPy
* Add, Mul, Pow now accept evaluate=False argument
