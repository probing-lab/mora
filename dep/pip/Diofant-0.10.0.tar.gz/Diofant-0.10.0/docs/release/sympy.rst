==============
SymPy releases
==============

For convenience, here included release notes from the old SymPy
versions, up to 0.7.6.  Changelog sources are taken `from web archive`_ and
adapted to resemble usual Diofant's release notes.

.. toctree::
   :glob:
   :maxdepth: 1
   :reversed:

   notes-0.5.[0-9]
   notes-0.5.1*
   notes-0.[67].*

.. _from web archive: http://web.archive.org/web/20111210113412/http://code.google.com/p/sympy/wiki/Changes
