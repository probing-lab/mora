============
SymPy 0.5.11
============

7 Jan 2008

* ``./setup.py install`` installs ``pyglet`` correctly now.
* ``var("k")`` fixed.
* Script for automatic testing of plotting in pure environment added.
