===========
SymPy 0.5.2
===========

20 Aug 2007

* concrete mathematics module written
* geometry module
* make the tarball conform to Debian policy
* many small bugs fixed
