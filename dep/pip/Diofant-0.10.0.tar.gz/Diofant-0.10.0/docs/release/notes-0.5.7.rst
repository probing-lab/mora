===========
SymPy 0.5.7
===========

17 Nov 2007

* ``isympy`` now uses 2D unicode pretty-printing by default.
* Convergence acceleration / extrapolation methods for series and sequences.
* SymPy was made ready to work nicely with SAGE.
