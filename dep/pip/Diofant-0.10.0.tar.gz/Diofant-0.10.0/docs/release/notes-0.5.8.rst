===========
SymPy 0.5.8
===========

6 Dec 2007

* ``_eval_apply()`` method was renamed to ``canonize()``.
* Added var from SAGE.
* Added more number theory functions.
* Spherical harmonics (Ylm) implemented.
* Functions interface simplified (SingleValuedFunction removed, nofargs -> nargs).
* Draw negative powers in denominator nicely.
* Integration of polynomials is 10x faster.
* ``pyglet`` updated to 1.0beta2.
