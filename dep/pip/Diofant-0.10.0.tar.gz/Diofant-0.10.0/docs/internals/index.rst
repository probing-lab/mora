Internals
=========

.. toctree::
   :maxdepth: 2

   polys
   gruntz
   hyperexpand
   g-functions
   evalf
   numeric-computation
   rewriting
