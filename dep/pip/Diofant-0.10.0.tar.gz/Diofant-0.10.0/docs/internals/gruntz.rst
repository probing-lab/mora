.. automodule:: diofant.series.gruntz
   :members:
