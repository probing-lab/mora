Algebraic equations
===================

.. automodule:: diofant.solvers.solvers
    :members:


Systems of Polynomial Equations
-------------------------------

.. automodule:: diofant.solvers.polysys
    :members:
