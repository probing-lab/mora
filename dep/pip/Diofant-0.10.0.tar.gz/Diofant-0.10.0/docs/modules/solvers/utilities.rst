Utilities for solving
=====================

.. autofunction:: diofant.solvers.deutils.ode_order
