Solvers
=======

.. automodule:: diofant.solvers

.. toctree::
   :caption: Contents
   :name: solverstoc
   :maxdepth: 2

   solvers
   inequalities
   diophantine
   ode
   recurr
   pde
   utilities
