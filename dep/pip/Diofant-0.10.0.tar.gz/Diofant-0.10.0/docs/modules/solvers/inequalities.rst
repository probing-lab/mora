.. _inequality-docs:

Inequality Solvers
==================

.. automodule:: diofant.solvers.inequalities
    :members:
