Recurrence Equations
====================

.. module:: diofant.solvers.recurr

.. autofunction:: rsolve

.. autofunction:: rsolve_poly

.. autofunction:: rsolve_ratio

.. autofunction:: rsolve_hyper
