.. _utilities-docs:

=========
Utilities
=========

.. automodule:: diofant.utilities

.. toctree::
   :caption: Contents
   :name: utiltoc
   :maxdepth: 2

   autowrap
   codegen
   decorator
   enumerative
   iterables
   lambdify
   memoization
   misc
   randtest
