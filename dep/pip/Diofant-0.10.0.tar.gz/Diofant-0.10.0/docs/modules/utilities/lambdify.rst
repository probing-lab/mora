========
Lambdify
========

.. automodule:: diofant.utilities.lambdify
   :members:
