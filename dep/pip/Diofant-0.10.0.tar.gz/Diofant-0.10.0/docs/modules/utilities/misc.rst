=============
Miscellaneous
=============

.. automodule:: diofant.utilities.misc
   :members:
