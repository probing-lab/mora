=========
Decorator
=========

.. automodule:: diofant.utilities.decorator
   :members:
