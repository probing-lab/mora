.. _combinatorics-subsets:

Subsets
=======

.. module:: diofant.combinatorics.subsets

.. autoclass:: Subset
   :members:

.. automethod:: diofant.combinatorics.subsets.ksubsets
