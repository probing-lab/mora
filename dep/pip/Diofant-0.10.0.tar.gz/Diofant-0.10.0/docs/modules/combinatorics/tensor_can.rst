.. _combinatorics-tensor_can:

Tensor Canonicalization
=======================

.. module:: diofant.combinatorics.tensor_can

.. autofunction:: canonicalize

.. autofunction:: double_coset_can_rep

.. autofunction:: get_symmetric_group_sgs

.. autofunction:: bsgs_direct_product
