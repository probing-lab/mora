.. _combinatorics-group_constructs:

Group constructors
==================

.. module:: diofant.combinatorics.group_constructs

.. autofunction:: DirectProduct
