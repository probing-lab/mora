.. _combinatorics-polyhedron:

Polyhedron
==========

.. module:: diofant.combinatorics.polyhedron

.. autoclass:: Polyhedron
   :members:
