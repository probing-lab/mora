.. _combinatorics-prufer:

Prufer Sequences
================

.. module:: diofant.combinatorics.prufer

.. autoclass:: Prufer
   :members:
