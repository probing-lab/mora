.. _combinatorics-perm_groups:

Permutation Groups
==================

.. module:: diofant.combinatorics.perm_groups

.. autoclass:: PermutationGroup
   :special-members:
   :private-members: _union_find_rep, _union_find_merge
   :members:
