3D Line
-------

.. automodule:: diofant.geometry.line3d
   :members:
