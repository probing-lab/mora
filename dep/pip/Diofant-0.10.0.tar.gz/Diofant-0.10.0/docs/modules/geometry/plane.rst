Plane
-----

.. automodule:: diofant.geometry.plane
   :members:
