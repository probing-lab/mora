Polygons
--------

.. module:: diofant.geometry.polygon

.. autoclass:: Polygon
   :members:

.. autoclass:: RegularPolygon
   :members:

.. autoclass:: Triangle
   :members:
