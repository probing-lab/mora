Entities
--------

.. module:: diofant.geometry.entity

.. autoclass:: diofant.geometry.entity.GeometryEntity
   :members:
