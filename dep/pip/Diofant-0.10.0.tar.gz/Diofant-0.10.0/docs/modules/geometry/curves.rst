Curves
------

.. module:: diofant.geometry.curve

.. autoclass:: Curve
   :members:
