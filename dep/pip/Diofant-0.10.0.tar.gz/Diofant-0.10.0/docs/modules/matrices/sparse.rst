Sparse Matrices
===============

.. automodule:: diofant.matrices.sparse
   :members:

ImmutableSparseMatrix Class Reference
-------------------------------------
.. autoclass:: diofant.matrices.immutable.ImmutableSparseMatrix
   :members:
