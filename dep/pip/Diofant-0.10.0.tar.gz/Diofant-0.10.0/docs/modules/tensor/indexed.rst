===============
Indexed Objects
===============

.. automodule:: diofant.tensor.indexed
   :members:
