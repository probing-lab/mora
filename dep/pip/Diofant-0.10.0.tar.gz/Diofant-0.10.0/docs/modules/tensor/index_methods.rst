=======
Methods
=======

.. automodule:: diofant.tensor.index_methods
   :members:
