===============================================
Essential Classes in diofant.vector (doctrings)
===============================================

CoordSysCartesian
=================

.. autoclass:: diofant.vector.coordsysrect.CoordSysCartesian
   :members:

   .. automethod:: diofant.vector.coordsysrect.CoordSysCartesian.__init__


Vector
======

.. autoclass:: diofant.vector.vector.Vector
   :members:


Dyadic
======

.. autoclass:: diofant.vector.dyadic.Dyadic
   :members:


Del
===

.. autoclass:: diofant.vector.deloperator.Del
   :members:
