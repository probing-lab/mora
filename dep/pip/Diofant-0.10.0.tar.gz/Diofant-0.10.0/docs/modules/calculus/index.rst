========
Calculus
========

.. automodule:: diofant.calculus

.. automodule:: diofant.calculus.euler
    :members:

.. automodule:: diofant.calculus.singularities
    :members:

.. automodule:: diofant.calculus.optimization
    :members:

.. automodule:: diofant.calculus.finite_diff
    :members:
