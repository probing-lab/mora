:orphan:

{{ fullname | escape | underline}}

.. currentmodule:: {{ module }}

method

.. auto{{ objtype }}:: {{ objname }}

