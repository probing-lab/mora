.. _distutils-user-guide:

NumPy Distutils - Users Guide
=============================

.. include:: ../../DISTUTILS.rst.txt
   :start-line: 6
