.. automodule:: scipy.linalg.blas
   :no-members:
   :no-inherited-members:
   :no-special-members:
