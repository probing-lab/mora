.. _optimize.root_scalar-bisect:

root_scalar(method='bisect')
----------------------------

.. scipy-optimize:function:: scipy.optimize.root_scalar
   :impl: scipy.optimize._root_scalar._root_scalar_bisect_doc
   :method: bisect

