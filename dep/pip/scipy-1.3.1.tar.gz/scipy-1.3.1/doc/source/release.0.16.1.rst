.. include:: ../release/0.16.1-notes.rst
