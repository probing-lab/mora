*************
Release Notes
*************

.. toctree::
   :maxdepth: 1

   release.1.3.1
   release.1.3.0
   release.1.2.1
   release.1.2.0
   release.1.1.0
   release.1.0.1
   release.1.0.0
   release.0.19.1
   release.0.19.0
   release.0.18.1
   release.0.18.0
   release.0.17.1
   release.0.17.0
   release.0.16.1
   release.0.16.0
   release.0.15.1
   release.0.15.0
   release.0.14.1
   release.0.14.0
   release.0.13.2
   release.0.13.1
   release.0.13.0
   release.0.12.1
   release.0.12.0
   release.0.11.0
   release.0.10.1
   release.0.10.0
   release.0.9.0
   release.0.8.0
   release.0.7.2
   release.0.7.1
   release.0.7.0
