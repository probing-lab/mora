
identity = lambda x: x
inc = lambda x: x + 1
dec = lambda x: x - 1

