"""
Tests for domains.
"""
