"""
Tests for polynomials.
"""
