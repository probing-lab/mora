"""
Tests for calculus package.
"""
