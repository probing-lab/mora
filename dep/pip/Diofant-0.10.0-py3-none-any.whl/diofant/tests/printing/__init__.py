"""
Printing tests.
"""
