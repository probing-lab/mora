"""
Tests for logic package.
"""
