"""
Tests for concrete mathematics.
"""
