"""
Tests for combinatorics package.
"""
