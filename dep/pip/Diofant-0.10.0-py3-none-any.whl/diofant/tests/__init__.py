"""
Generic tests.
"""
