"""
Tests for optional external dependencies.
"""
