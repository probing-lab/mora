"""
Tests for geometry package.
"""
