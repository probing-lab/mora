"""
Tests for plotting.
"""
