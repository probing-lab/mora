"""
Tests for functions module.
"""
