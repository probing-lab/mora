"""
Tests for elementary functions.
"""
