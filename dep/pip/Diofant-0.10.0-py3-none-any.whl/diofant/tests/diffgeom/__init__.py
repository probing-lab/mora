"""
Tests for diffgeom package.
"""
