"""
Tests for number theory.
"""
