"""
Tests for matrix expressions.
"""
