"""
Tests for matrices.
"""
