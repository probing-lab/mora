"""
Tests for integrals.
"""
