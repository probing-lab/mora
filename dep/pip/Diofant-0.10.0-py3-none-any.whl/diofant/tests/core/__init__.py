"""
Tests for core package.
"""
