"""
Tests for interactive sessions.
"""
