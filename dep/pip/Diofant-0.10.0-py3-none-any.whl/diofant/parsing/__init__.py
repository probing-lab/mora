"""Used for translating a string into a Diofant expression. """
