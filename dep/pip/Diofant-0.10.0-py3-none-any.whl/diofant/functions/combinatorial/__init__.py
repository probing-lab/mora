"""
Package for combinatorial functions.
"""

from . import factorials  # noqa: F401
from . import numbers  # noqa: F401
